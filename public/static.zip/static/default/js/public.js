/**
 * Created by blue on 14-7-12.
 */
/**
 * 模拟alert方法
 *
 * @parem String content
 * @return void
 * */
window.alert = function(content)
{
    if (document.getElementsByClassName('alterClose').length)
    {
        return false;
    }
    var win = '<div class="window">'
    win += '<div class="caption">'
    win += '<span class="icon icon-windows"></span> '
    win += '<div class="title">Message</div> '
    // win += '<button class="btn-min"></button> '
    // win += '<button class="btn-max"></button> '
    win += '<button class="btn-close alterClose"></button> '
    win += "</div>"
    win += '<div class="content" style="text-align:center">'
    win += content
    win += "</div>"
    win += "<div style='text-align:center;'><button class='alterClose'>确定</button></div>"
    win += "</div>"
    var div = document.createElement('div');
    div.innerHTML = win;
    div.style.position = "absolute";

    div.style.left = window.outerWidth / 2.5 + 'px';
    div.style.top = window.outerHeight / 5 + 'px';
    // div.style.zIndex=1111
    div.style.width = 400+'px';

    document.getElementsByClassName('metro')[0].appendChild(div);
    var remove = document.getElementsByClassName('alterClose');
    var i = 0;
    var len = remove.length;
    for( i;i<len;i++)
    {
        remove[i].onclick = function()
        {
            document.getElementsByClassName('metro')[0].removeChild(div);
        }
    }
}
/**
 * 自动适应window高度
 *
 * @parem String ele
 * @return void
 * */
function autoScroll(ele)
{
    var srcollContainer = document.getElementsByClassName(ele);
    var i = 0;
    var len = srcollContainer.length;
    for( i;i<len;i++)
    {
        srcollContainer[i].style.height = window.innerHeight-63+'px';
    }
}
window.onresize = function()
{
    autoScroll('srcollContainer')
}
